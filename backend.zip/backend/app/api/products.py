from fastapi import APIRouter, Depends, HTTPException
from sqlmodel import Session, select
from typing import List
from app.models import Product
from app.dependencies import get_session

router = APIRouter()

@router.post("/products", response_model=Product)
def create_product(product: Product, session: Session = Depends(get_session)):
    existing = session.exec(select(Product).where(Product.item_nbr == product.item_nbr)).first()
    if existing:
        raise HTTPException(status_code=400, detail="Product already exists")
    session.add(product)
    session.commit()
    session.refresh(product)
    return product

@router.get("/products", response_model=List[Product])
def get_products(session: Session = Depends(get_session)):
    return session.exec(select(Product)).all()

@router.put("/products/{product_id}")
def update_product_quantity(product_id: int, new_units: int, session: Session = Depends(get_session)):
    product = session.get(Product, product_id)
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    product.units = new_units
    session.commit()
    return {"message": "Quantity updated"}
