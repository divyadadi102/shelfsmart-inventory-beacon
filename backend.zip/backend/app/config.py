from datetime import date

DEMO_DATE = date(2017, 8, 15)
