# backend/app/main.py

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .database import create_db_and_tables
from .api import auth, upload, sales
from .api.sales import router as sales_router
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
import os

app = FastAPI(
    title="ShelfSmart API",
    description="AI-powered data analytics platform API",
    version="1.0.0"
)

# CORS 配置：前端本地调试
origins = [
    "http://localhost:3000",  # 如果前端是 Vite，端口一般是 5173，可一起加
    "http://localhost:5173",
    "http://127.0.0.1:3000",
    "http://127.0.0.1:5173",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],   # 或者明确列出前端 URL
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 注册路由
"""app.include_router(auth.router, prefix="/api")"""
app.include_router(auth.router, prefix="/auth")

# 启动时建表
@app.on_event("startup")
def on_startup():
    create_db_and_tables()

# 可选：根路由
@app.get("/")
def read_root():
    return {"message": "ShelfSmart backend is running"}

app.include_router(upload.router, prefix="/api")

app.include_router(sales.router, prefix="/api")

# 注册API路由
app.include_router(sales_router)


# 挂载静态文件夹，方便管理
app.mount("/static", StaticFiles(directory=os.path.join(os.path.dirname(__file__), "static")), name="static")

@app.get("/api/download-template")
def download_template():
    file_path = os.path.join(os.path.dirname(__file__), "static", "sample_template.csv")
    return FileResponse(
        path=file_path,
        media_type="text/csv",
        filename="sample_template.csv"
    )
